function faq_action(){
$( '.rcon table td a' ).click(
            function() {
                $(this).parent().parent().next().find(".answer").toggle();
                
            }
 );
}