    $(document).ready(function(){
        $("#content div.pic ul li img").mouseover(function(){
            $(".show_img").attr("src",$(this).attr("src"));
        });
        
        
        $(".tab3 .tab3_wrap1 li img").mouseover(function(){
            $(".tab3 .show_pic1").attr("src",$(this).attr("src"));
        });
        
		 $(".tab3 .tab3_wrap2 li img").mouseover(function(){
            $(".tab3 .show_pic2").attr("src",$(this).attr("src"));
        });

		
		 $(".tab3 .tab3_wrap3 li img").mouseover(function(){
            $(".tab3 .show_pic3").attr("src",$(this).attr("src"));
        });

		 $(".tab3 .tab3_wrap4 li img").mouseover(function(){
            $(".tab3 .show_pic4").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap5 li img").mouseover(function(){
            $(".tab3 .show_pic5").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap6 li img").mouseover(function(){
            $(".tab3 .show_pic6").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap7 li img").mouseover(function(){
            $(".tab3 .show_pic7").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap8 li img").mouseover(function(){
            $(".tab3 .show_pic8").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap9 li img").mouseover(function(){
            $(".tab3 .show_pic9").attr("src",$(this).attr("src"));
        });


		 $(".tab3 .tab3_wrap10 li img").mouseover(function(){
            $(".tab3 .show_pic10").attr("src",$(this).attr("src"));
        });

		



		 $(".foot .thm1").mouseover(function(){
            $(".foot .show_pic1").attr("src",$(this).attr("src"));
        });
		
		
		 $(".foot .thm2").mouseover(function(){
            $(".foot .show_pic2").attr("src",$(this).attr("src"));
        });
	

    });